# CalCentral Meal Plan Fix
Browser extension to restore meal plan information to CalCentral

![Demo](https://i.imgur.com/WTN0XyX.png)

![Swipes Demo](https://i.imgur.com/0PJyBC4.png)

![C1C Demo](https://i.imgur.com/kubjnvE.png)

![CD Demo](https://i.imgur.com/uYw3hJ6.png)
